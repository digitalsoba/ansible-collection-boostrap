# Ansible Collection - digitalsoba.bootstrap

Ansible collections for roles I used for my homelab. 